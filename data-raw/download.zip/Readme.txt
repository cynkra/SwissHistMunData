De:
Gegen�ber der Version die am 10. April 2014 ver�ffentlicht wurde, ist in dieser Version das Feld DateOfChange f�r die Historisierte Gemeindenummern 14791 und 14839 auf den 30.04.2014 korrigiert.

Fr:
Par rapport � la version publi�e le 10 avril 2014, la valeur du champ DateOfChange a �t� corrig�e au 30.04.2014 dans la pr�sente version pour les num�ros de communes historis�s 14791 et 14839.
